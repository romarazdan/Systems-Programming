/*******************************************************************************
 * Name        : pfind.c
 * Author      : Michael Zylka, Roma Razdan
 * Date        : 3/9/2021
 * Description : Finds files with a specified set of permissions.
 * Pledge      : I pledge my honor that I have abided by the Stevens Honor System.
 ******************************************************************************/
#include <stdio.h>
#include <getopt.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>

int perms[] = {S_IRUSR, S_IWUSR, S_IXUSR,
               S_IRGRP, S_IWGRP, S_IXGRP,
               S_IROTH, S_IWOTH, S_IXOTH};

void permission_checker(char* permissions) {
    int index = 0;
    while (*(permissions + index) != '\0') {
        char character = *(permissions + index);

        if (index % 3 == 0 && character != 'r' && character != '-') {
            fprintf(stderr, "Error: Permissions string '%s' is invalid.\n", permissions);
            exit(EXIT_FAILURE);
        }
        else if (index % 3 == 1 && character != 'w' && character != '-') {
            fprintf(stderr, "Error: Permissions string '%s' is invalid.\n", permissions);
            exit(EXIT_FAILURE);
        }
        else if (index % 3 == 2 && character != 'x' && character != '-') {
            fprintf(stderr, "Error: Permissions string '%s' is invalid.\n", permissions);
            exit(EXIT_FAILURE);
        }

        index++;
    }

    if (index > 9 || index < 9) {
            fprintf(stderr, "Error: Permissions string '%s' is invalid.\n", permissions);
            exit(EXIT_FAILURE);
    }

}


int permission_converter(char* permissions) {
    int index = 0;
    int output = 0;
    while (*(permissions + index) != '\0') {
        char character = *(permissions + index);
        if(index < 3 && character != '-') {
            output = output | ((4 >> (index % 3)) << 6);
        }
        else if(index < 6 && character != '-') {
            output = output | ((4 >> (index % 3)) << 3);
        }
        else if(index < 9 && character != '-') {
            output = output | (4 >> (index % 3));
        }

        index++;
    }

    return output;
}

int get_perms(struct stat *statbuf) {
    int output = 256;
    for(int i = 0; i < 9; i++) {
        int permission_valid = statbuf->st_mode & perms[i];
        if (permission_valid) {
            output = output | permission_valid;
        }
    }
    return output;
}


void find_perms(char *directory, int permissions) {
    DIR *dp;
    struct dirent *dent;
    struct stat sb;

    if(lstat(directory, &sb) < 0) {
        fprintf(stderr, "Error: Cannot stat '%s'. %s.\n", directory, strerror(errno));
        exit(EXIT_FAILURE);
    }

    char path[PATH_MAX];
    if (realpath(directory, path) == NULL) {
        fprintf(stderr, "Error: Cannot get full path of file '%s'. %s\n", path, strerror(errno));
        return;
    }

    char fullFileName[PATH_MAX + 1];
    size_t pathlen = 0;

    fullFileName[0] = '\0';
    if (strcmp(path, "/")) {
        strncpy(fullFileName, path, PATH_MAX);
    }

    pathlen = strlen(fullFileName) +1;
    fullFileName[pathlen] = '\0';

    if ((dp = opendir(directory)) == NULL) {
        fprintf(stderr, "Error: Cannot open directory '%s'. %s.\n", fullFileName, strerror(errno));
        return;
    }
    fullFileName[pathlen -1] = '/';

    errno = 0; 
    while ((dent = readdir(dp))!= NULL) {
        if (strcmp(dent->d_name, "..") != 0 && strcmp(dent->d_name, ".") != 0 ) {
            strncpy(fullFileName + pathlen, dent ->d_name, PATH_MAX - pathlen);

            if(lstat(fullFileName, &sb) < 0) {
                fprintf(stderr, "Error: Cannot stat file '%s'. %s.\n", dent->d_name, strerror(errno));
            }

            int currentPerms = get_perms(&sb);

            if (currentPerms == permissions) {
                printf("%s\n", fullFileName);
            }
            if (S_ISDIR(sb.st_mode)) {
                find_perms(fullFileName, permissions);
            }
            errno = 0;
        }
    }

    closedir(dp);

    if (errno != 0) {
        fprintf(stderr, "Error: An error occured while reading the directory. %s \n", strerror(errno));
        exit(EXIT_FAILURE);
    }
}


int main(int argc,  char *argv[]) {
    if (argc == 1) { 
        printf("Usage: %s -d <directory> -p <permissions string> [-h]\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    int dFlag = 0;
    int pFlag = 0;
    char *directory;
    char *permissions;
    int c;

    opterr = 0;

    while ((c = getopt(argc, argv, "hd:p:")) != -1) {
        switch (c) {
            case 'd':
                dFlag = 1;
                directory = optarg;
                break;
            case 'p':
                pFlag = 1;
                permissions = optarg;
                break;
            case 'h':
                printf("Usage: %s -d <directory> -p <permissions string> [-h]\n", argv[0]);
                exit(EXIT_SUCCESS);
            case ':':
                printf("option needs a value\n");     
            case '?':
                if (optopt == 'd') {
                    fprintf(stderr, "Error: Required argument -%c <directory> not found.\n", optopt);
                    exit(EXIT_FAILURE);
                }
                else if (optopt == 'p') {
                    if (dFlag == 0) {
                        fprintf(stderr, "Error: Required argument -%c <directory> not found.\n", 'd');
                        exit(EXIT_FAILURE);
                    }
                    fprintf(stderr, "Error: Required argument -%c <permissions string> not found.\n", optopt);
                    exit(EXIT_FAILURE);
                }
                else if (isprint(optopt)) {
                    fprintf(stderr, "Error: Unknown option '-%c' received.\n", optopt);
                    exit(EXIT_FAILURE);
                }
            default:
                abort();
        }
    }

    if (dFlag == 0 || directory == NULL) {
        fprintf(stderr, "Error: Required argument -d <directory> not found.\n");
        exit(EXIT_FAILURE);
    }
    else if(pFlag == 0 || permissions == NULL) {
        fprintf(stderr, "Error: Required argument -p <permissions string> not found.\n");
        exit(EXIT_FAILURE);
    }
    struct stat sb;

    if(lstat(directory, &sb) < 0) {
        fprintf(stderr, "Error: Cannot stat file '%s'. %s.\n", directory, strerror(errno));
        exit(EXIT_FAILURE);
    }

    permission_checker(permissions);

    int binary_perms = permission_converter(permissions);
    
    find_perms(directory, binary_perms);
    
    exit(EXIT_SUCCESS);
}



