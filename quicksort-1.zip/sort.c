/*******************************************************************************
 * Name        : sort.c
 * Author      : Michael Zylka, Roma Razdan
 * Date        : 2/24/2021
 * Description : Uses quicksort to sort a file of either ints, doubles, or
 *               strings.
 * Pledge      : I pledge my honor that I have abided by the Stevens Honor System.
 ******************************************************************************/
#include <errno.h>
#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include "quicksort.h"


#define MAX_STRLEN     64 // Not including '\0'
#define MAX_ELEMENTS 1024

typedef enum {
    STRING,
    INT,
    DOUBLE
} elem_t;


/**
 * Reads data from filename into an already allocated 2D array of chars.
 * Exits the entire program if the file cannot be opened.
 */
size_t read_data(char *filename, char **data) {
    // Open the file.
    FILE *fp = fopen(filename, "r");
    if (fp == NULL) {
        fprintf(stderr, "Error: Cannot open '%s'. %s.\n", filename,
                strerror(errno));
        free(data);
        exit(EXIT_FAILURE);
    }

    // Read in the data.
    size_t index = 0;
    char str[MAX_STRLEN + 2];
    char *eoln;
    while (fgets(str, MAX_STRLEN + 2, fp) != NULL) {
        eoln = strchr(str, '\n');
        if (eoln == NULL) {
            str[MAX_STRLEN] = '\0';
        } else {
            *eoln = '\0';
        }
        // Ignore blank lines.
        if (strlen(str) != 0) {
            data[index] = (char *)malloc((MAX_STRLEN + 1) * sizeof(char));
            strcpy(data[index++], str);
        }
    }

    // Close the file before returning from the function.
    fclose(fp);

    return index;
}

void print_help() {
    fprintf(stderr, "Usage: ./sort [-i|-d] filename\n   -i: Specifies the file contains ints.\n   -d: Specifies the file contains doubles.\n   filename: The file to sort.\n   No flags defaults to sorting strings.\n");
}

void print_arr(void* array, int last) {

    for (int i = 0; i < last; i ++) {
        printf("%s\n", *((char**)array + i));
    }
}

/**
 * Basic structure of sort.c:
 *
 * Parses args with getopt.
 * Opens input file for reading.
 * Allocates space in a char** for at least MAX_ELEMENTS strings to be stored,
 * where MAX_ELEMENTS is 1024.
 * Reads in the file
 * - For each line, allocates space in each index of the char** to store the
 *   line.
 * Closes the file, after reading in all the lines.
 * Calls quicksort based on type (int, double, string) supplied on the command
 * line.
 * Frees all data.
 * Ensures there are no memory leaks with valgrind. 
 */
int main(int argc, char **argv) {
    
    int intFlag = 0;
    int doubleFlag = 0;
    int stringFlag = 0;
    char *fileName;
    int c;

    opterr = 0;

    while ((c = getopt (argc, argv, "id")) != -1) {
        switch (c) {
            case 'i':
                intFlag = 1;
                break;
            case 'd':
                doubleFlag = 1;
                break;
            case '?':
                if (isprint(optopt) ) {
                    fprintf (stderr, "Error: Unknown option '-%c' received.\n", optopt);
                    print_help();
                }
                return EXIT_FAILURE;
            default: 
                abort();
        }
    }

    fileName = argv[optind];

    if (intFlag == 0 && doubleFlag == 0) {
        stringFlag = 1;
    }

    if (stringFlag == 1 && fileName == NULL) {
        print_help();
        return EXIT_FAILURE;
    }

    else if ((intFlag == 1 || doubleFlag == 1) && fileName == NULL) {
        fprintf (stderr, "Error: No input file specified.\n");
        return EXIT_FAILURE;
    }

    else if (intFlag + doubleFlag + stringFlag > 1) {
        fprintf (stderr, "Error: Too many flags specified.\n");
        return EXIT_FAILURE;
    } 


    if ((argc >= 3 && stringFlag == 1) || argc >= 4) {
        fprintf(stderr, "Error: Too many files specified.\n");
        return EXIT_FAILURE;
    }

    
    char** array = (char**)malloc(MAX_ELEMENTS * sizeof(char*));

    size_t last = read_data(fileName, array);

    if (intFlag == 1) 
        quicksort(array, (int) last, sizeof(int), int_cmp);
    else if (doubleFlag == 1)
        quicksort(array, (int)last, sizeof(double), dbl_cmp);
    else 
        quicksort(array, (int)last, MAX_STRLEN, str_cmp);
    

    print_arr(array, last);

    for (int i = 0; i < last; i++) {
        free(array[i]);
    }
    free(array);

    return EXIT_SUCCESS;
}
