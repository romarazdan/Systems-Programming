/*******************************************************************************
 * Name        : minishell.c
 * Author      : Michael Zylka, Roma Razdan
 * Date        : 4/7/2021
 * Description : Simulates a shell.
 * Pledge      : I pledge my honor that I have abided by the Stevens Honor System.
 ******************************************************************************/

#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <setjmp.h>
#include <pwd.h>



#define BRIGHTBLUE "\x1b[34;1m"
#define DEFAULT    "\x1b[0m"

volatile sig_atomic_t sig = 0;
sigjmp_buf jmpbuf;

int setargs(char * args, char ** argv) {
    int count = 0;
    while(*args == ' ') { 
        ++args;
    }
    while(*args) {
        if (argv) argv[count] = args;
        while (*args && !(*args == ' ')) {
            ++args;
        }
        if (argv && *args) {
            *args++ = '\0';
        }
        while(*args == ' ') {
            ++args;
        }
        count++;
    }
    return count;
}

char **parseargs(int *argc, char *args) {
    int argnum = 0;
    char ** argv = NULL;
    
    if (args && *args && (args = strdup(args)) && (argnum = setargs(args, NULL)) && (argv = malloc((argnum + 2) * sizeof(char *)))) {
        *argv++ = args;
        argnum = setargs(args, argv);
    }

    if (args && !argv) {
        free(args);
    }

    *argc = argnum;
    argv[argnum] = NULL;
    return argv;
}

void freeparsedargs(char **argv) {
      if (argv) {
        free(argv[-1]);
        free(argv-1);
      } 
}

void catch_signal(int sig) {
    write(STDOUT_FILENO, "\n", 1);
    siglongjmp(jmpbuf, 1);
}

//function to handle the cd command
void cd(int argc, char** argv, char* path) {

    char* newPath;
    if (argc > 2) {
        fprintf(stderr, "Error: Too many Arguments to cd.\n");
        return;
    }
    else if (argc == 1 || strncmp(argv[1], "~", 1) == 0) {
        struct passwd *pwd;
        if ((pwd = getpwuid(getuid())) == NULL ) {
            fprintf(stderr, "Error: Cannot get passwd entry. %s\n", strerror(errno));
            return;
        }

        if (strncmp(argv[1], "~/", 2) == 0){
            if ((newPath = malloc(strlen(pwd->pw_dir) + strlen(argv[1])))== NULL) {
                fprintf(stderr, "Error: malloc() failed. %s.\n", strerror(errno));
                return;
            }
            strcpy(newPath, pwd->pw_dir);
            strcat(newPath, "/");
            strcat(newPath, argv[1] + 2);
        }
        else{
            newPath = malloc(strlen(pwd->pw_dir));
            newPath = pwd->pw_dir;
        }    
    }

    else {
        if ((newPath = malloc(strlen(path) + strlen(argv[1])))== NULL) {
            fprintf(stderr, "Error: malloc() failed. %s.\n", strerror(errno));
            return;
        }
        strcpy(newPath, path);
        strcat(newPath, "/");
        strcat(newPath, argv[1]);
    }

    if (chdir(newPath) == -1) {
        fprintf(stderr, "Error: Cannot change directory to '%s'. %s\n", argv[1], strerror(errno));
    }

}

void execute(char ** argv) {
    pid_t pid;
    int status;

    if ((pid = fork()) == 0) {
        if (execvp(argv[0], argv) == -1) {
            fprintf(stderr, "Error: exec() failed. %s.\n", strerror(errno));
            exit(EXIT_FAILURE);
        }
    }
    else if(pid > 0) {
        while(wait(&status) != pid) {
            if (status != SIGINT) {
                fprintf(stderr, "Error: wait() failed. %s.\n", strerror(errno));
            }
        }
    }
    else {
        fprintf(stderr, "Error: fork() failed. %s\n", strerror(errno));
    }
}


int main() {

    char path[PATH_MAX];

    struct sigaction action;
    memset(&action, 0, sizeof(struct sigaction));
    action.sa_handler = catch_signal;
    if(sigaction(SIGINT, &action, NULL) == -1) {
        fprintf(stderr, "Error: Cannot register signal handler. %s", strerror(errno));
        perror("sigaction");
        exit(EXIT_FAILURE);
    }

    //main loop for the minishell
    while (1) {
        
        //string definition for User input
        char buf[1024];
        sigsetjmp(jmpbuf, 1);

        //get the current working directory
        if (getcwd(path, PATH_MAX) == NULL) {
            fprintf(stderr, "Error: Cannot get current working directory. %s\n", strerror(errno));
            exit(EXIT_FAILURE);
        }

        //print the current working directory
        printf("[%s%s%s]$ ", BRIGHTBLUE, path, DEFAULT);
        
        //get the input from stdin
        if (fgets(buf, sizeof(buf), stdin) == NULL)  {
            fprintf(stderr, "Error: Failed to read from stdin. %s\n", strerror(errno));
            exit(EXIT_FAILURE);
        }
        if (strncmp(buf, "\n", 1) != 0){
            *(buf + strlen(buf) -1) = '\0'; 

            int argc;
            char **argv = parseargs(&argc, buf);
            
            //if the user types in cd
            if (strcmp(argv[0], "cd") == 0) {
                cd(argc, argv, path);
            }
            
            else if (strcmp(argv[0], "exit") == 0) {
                freeparsedargs(argv);
                exit(EXIT_SUCCESS);
            }

            else {
                execute(argv);
            }

            freeparsedargs(argv);
        }
    }
}